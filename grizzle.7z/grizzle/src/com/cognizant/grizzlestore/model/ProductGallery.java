package com.cognizant.grizzlestore.model;

public class ProductGallery {

	public ProductGallery() {
		// TODO Auto-generated constructor stub
	}

	ProductDetails productDetails;
	String imageUrl;
	public ProductDetails getProductDetails() {
		return productDetails;
	}
	public void setProductDetails(ProductDetails productDetails) {
		this.productDetails = productDetails;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public ProductGallery(ProductDetails productDetails, String imageUrl) {
		super();
		this.productDetails = productDetails;
		this.imageUrl = imageUrl;
	}
	@Override
	public String toString() {
		return "ProductGallery [productDetails=" + productDetails + ", imageUrl=" + imageUrl + "]";
	}
	
	
}
