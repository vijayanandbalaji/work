package com.cognizant.grizzlestore.model;

public class ProductCategory {

	public ProductCategory() {
		// TODO Auto-generated constructor stub
	}
	private int categoryId;
	private String catogoryName;
	public ProductCategory(int categoryId, String catogoryName) {
		super();
		this.categoryId = categoryId;
		this.catogoryName = catogoryName;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getCatogoryName() {
		return catogoryName;
	}
	public void setCatogoryName(String catogoryName) {
		this.catogoryName = catogoryName;
	}
	
	@Override
	public String toString() {
		return "ProductCategory [categoryId=" + categoryId + ", catogoryName=" + catogoryName + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + categoryId;
		result = prime * result + ((catogoryName == null) ? 0 : catogoryName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductCategory other = (ProductCategory) obj;
		if (categoryId != other.categoryId)
			return false;
		if (catogoryName == null) {
			if (other.catogoryName != null)
				return false;
		} else if (!catogoryName.equals(other.catogoryName))
			return false;
		return true;
	}
	
	
	

}
