package com.cognizant.grizzlestore.model;

public interface ILoginDao {
	
	LoginDetails checkLogin(LoginDetails loginDetails);
	int checkUsername(String username);
	int updateStatus(String username);
	int getStatus(String username);
}
