package com.cognizant.grizzlestore.controller;

import java.io.IOException;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.grizzlestore.dao.GalleryDao;
import com.cognizant.grizzlestore.dao.ProductDao;
import com.cognizant.grizzlestore.exception.GrizzleException;
import com.cognizant.grizzlestore.model.ProductBrands;
import com.cognizant.grizzlestore.model.ProductCategory;
import com.cognizant.grizzlestore.model.ProductDetails;
import com.cognizant.grizzlestore.model.ProductGallery;

/**
 * Servlet implementation class GrizzleController
 */
@WebServlet("/GrizzleController")
public class GrizzleController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GrizzleController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		try {
	//if back is clicked displat the page with data
			if(request.getParameter("Back")!=null) {
				ProductDao productDao=new ProductDao();
				List<ProductDetails> list=	productDao.getProductDetails("");
				System.out.println(list);
				request.setAttribute("productList", list);
				RequestDispatcher dispatcher=request.getRequestDispatcher("/jsp/home.jsp");
				dispatcher.forward(request, response);
	
			}
			
			
		// for view
		
	if(request.getParameter("View")!=null) {
			String path="";
			
			
	String pid[]=	request.getParameterValues("productId");
	StringBuffer sb=new StringBuffer();
	for (int i = 0; i < pid.length; i++) {
		sb.append(pid[i]).append(",");
	}
	sb.deleteCharAt(sb.length()-1);
	ProductDao productDao=new ProductDao();
try {
	List<ProductDetails> details=	productDao.getProductDetails(sb.toString());
	request.setAttribute("productList", details);
	path="/jsp/viewproduct.jsp";
	
} catch (GrizzleException e) {
	// TODO Auto-generated catch block
	path="/jsp/success.jsp";
	request.setAttribute("error", e.getMessage());
	
	e.printStackTrace();
}catch (Exception e) {
	// TODO Auto-generated catch block
	request.setAttribute("error", e.getMessage());
	e.printStackTrace();
}
RequestDispatcher dispatcher=request.getRequestDispatcher(path);
dispatcher.forward(request, response);


		
		
			
		}
		// for remove
	if(request.getParameter("Remove")!=null) {
		String path="/jsp/success.jsp";
		// display another page saying that products blocked
		
		String pid[]=	request.getParameterValues("productId");
		ProductDao dao=new ProductDao();
		GalleryDao dao2=new GalleryDao();
		int pidd[];
		
		pidd=new int[pid.length];
		for (int i = 0; i < pid.length; i++) {
			pidd[i]=Integer.parseInt(pid[i]);
			
		}
		
		try {
		int count=	dao.deleteProductDetails(pidd);
		int count2=	dao2.deleteProductImages(pidd);
		
		if(count>0 && count2>0) {
			
			request.setAttribute("message", "removed product and its gallery");
			System.out.println("removed product and its gallery");
		}	else {
			
			request.setAttribute("message", "Not removed product and its gallery");
			System.out.println("not removes product and gallery");
		}
		
		
			
		} catch (GrizzleException e) {
			// TODO Auto-generated catch block
			
			request.setAttribute("error", e.getMessage());
			e.printStackTrace();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			request.setAttribute("error", e.getMessage());
			e.printStackTrace();
		}
		
		RequestDispatcher dispatcher=request.getRequestDispatcher(path);
		dispatcher.forward(request, response);


		
		
	}
	
	// for block
if(request.getParameter("Block")!=null) {
	String path="/jsp/success.jsp";
	// display another page saying that products removed
	String pid[]=	request.getParameterValues("productId");
	ProductDao dao=new ProductDao();
	int pidd[];
	
pidd=new int[pid.length];
	for (int i = 0; i < pid.length; i++) {
		pidd[i]=Integer.parseInt(pid[i]);
		
	}
	
	try {
	int count=	dao.updateProductDetails(pidd, "block");
	if(count>0) {
		request.setAttribute("message", "Product updated to block");
		System.out.println("updated to block");
	}	else {
		request.setAttribute("message", "Product not updated to block");
		System.out.println("not updatd to block");
	}
	
	
		
	} catch (GrizzleException e) {
		// TODO Auto-generated catch block
		request.setAttribute("error", e.getMessage());
		e.printStackTrace();
	}catch (Exception e) {
		// TODO Auto-generated catch block
		request.setAttribute("error", e.getMessage());
		e.printStackTrace();
	}
	
	RequestDispatcher dispatcher=request.getRequestDispatcher(path);
	dispatcher.forward(request, response);

	
	
}


	
		
		
		
		
		
		// for add product
		
		if(request.getParameter("Add Product")!=null) {
	        String path="/jsp/success.jsp";	
			String productName=request.getParameter("productName");
			String productPrice=request.getParameter("productPrice");
			String productBrand=request.getParameter("brand");
			String productCategory=request.getParameter("category");
			
			
			
			String productDesc=request.getParameter("description");
		//	String imageUrl[]=request.getParameterValues("filenames");
			double price=Double.parseDouble(productPrice);
			int categoryId=Integer.parseInt(productCategory);
			int brandId=Integer.parseInt(productBrand);
			ProductBrands productBrands=new ProductBrands(brandId, "");
			ProductCategory productCategory2=new ProductCategory(categoryId, "");
			
			String imageUrl[]=request.getParameterValues("filenames");
			
			StringBuffer sb=new StringBuffer();
			
			
			for (int i = 0; i < imageUrl.length; i++) {
				System.out.println(imageUrl[i]);
			       //String path[]= imageUrl[0].split("//");
				//sb.append(path[path.length-1]);
			      sb.append(imageUrl[i]) ; 
			        
				sb.append(",");
			}
			sb.deleteCharAt(sb.length()-1);
			ProductDao productDao=new ProductDao();
			GalleryDao galleryDao=new GalleryDao();
			ProductDetails details=new ProductDetails(0, productName, productDesc, price, 1.5, "available", productBrands, productCategory2, sb.toString());
			try {
			int productId=	productDao.saveProductDetails(details);
			details.setProductId(productId);
			ProductGallery gallery=new ProductGallery(details, sb.toString());
			int galleryId=galleryDao.saveProductImages(gallery);
			if(productId<0 && galleryId<0) {
				request.setAttribute("message", "Product and Gallery is  not added "+productId+"gle"+galleryId);
				System.out.println("Product and Gallery is  not added "+productId+"gle"+galleryId);
				
			}else {
				request.setAttribute("message", "Product and Gallery is   added "+productId+"gle"+galleryId);
				
				System.out.println("Product And gallery is added "+productId+"gle"+galleryId);
					
				
			}
			} catch (GrizzleException e) {
				// TODO Auto-generated catch block
				request.setAttribute("error", e.getMessage());
				
				e.printStackTrace();
			}catch (Exception e) {
				// TODO Auto-generated catch block
				request.setAttribute("error", e.getMessage());
				e.printStackTrace();
			}
			RequestDispatcher dispatcher=request.getRequestDispatcher(path);
			dispatcher.forward(request, response);

			
			
			
		}
		
		
		
		
		}catch(Exception e) {
			request.setAttribute("error","Plz provide correct Input");
			System.out.println(e.getMessage());
			RequestDispatcher dispatcher=request.getRequestDispatcher("/jsp/success.jsp");
			dispatcher.forward(request, response);

		}
		
	}

}
