package com.cognizant.grizzlestore.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.grizzlestore.dao.LoginDao;
import com.cognizant.grizzlestore.exception.GrizzleException;
import com.cognizant.grizzlestore.model.LoginDetails;

/**
 * Servlet implementation class LogoutController
 */
@WebServlet("/LogoutController")
public class LogoutController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LogoutController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		LoginDetails details=(LoginDetails) session.getAttribute("user");
		
		System.out.println("from logout controller success fully logout");
		session.invalidate();
		
		LoginDao dao=new LoginDao();
		try {
		int flag=	dao.afterLogoutUpdateStatus(details.getUsername());
		if(flag>0) {
			//request.setAttribute("message","User");
			
			System.out.println("updated");
		}else {
			//request.setAttribute("error",e.getMessage());
			
			System.out.println("Not updated");
		}
		
		} catch (GrizzleException e) {
			request.setAttribute("error",e.getMessage());
			request.getRequestDispatcher("/jsp/success.jsp").forward(request, response);
		}
		response.sendRedirect("/grizzle/jsp/login.jsp");
		
		
	}

	

}
