package com.cognizant.grizzlestore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cognizant.grizzlestore.exception.GrizzleException;
import com.cognizant.grizzlestore.model.ProductCategory;
import com.cognizant.grizzlestore.model.ProductDetails;
import com.cognizant.grizzlestore.model.ProductGallery;
import com.cognizant.grizzlestore.util.ConnectionUtil;
import com.cognizant.grizzlestore.util.IGrizzleMessages;

public class GalleryDao {

	public GalleryDao() {
		// TODO Auto-generated constructor stub
	}
	public int saveProductImages(ProductGallery productGallery) throws GrizzleException {

		 Connection connObj=null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int empId = 0;
		//insert into product values(1,'bulb','bulb rises when sunset',1234.34,1.4,1002,103,"available");
//
		String query = "insert into product_gallery(pr_id_fk, pr_img_name) values(?,?)" ;
		try {
			connObj=ConnectionUtil.getConnection();
			if (connObj == null) {
				System.out.println("not Got connection");
			} else {
				System.out.println("Got Connected");
			}
			preparedStatement = connObj.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);

			preparedStatement.setInt(1, productGallery.getProductDetails().getProductId());
			preparedStatement.setString(2, productGallery.getImageUrl());
			
			int count = preparedStatement.executeUpdate();

			resultSet = preparedStatement.getGeneratedKeys();
			if (resultSet.next()) {
				empId = resultSet.getInt(1);
			}

			if (count >= 1) {
				System.out.println("Product images save");
			} else {

				throw new GrizzleException("Product images is not saved some internal error");
			}

			/*
			 * if(resultSet!=null) resultSet.close();
			 */

		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			// classNotFoundException.printStackTrace();
			throw new GrizzleException(IGrizzleMessages.SOME_SQL_ERROR);
		} catch (Exception e) {
			e.printStackTrace();
			throw new GrizzleException(IGrizzleMessages.CONTACT_TO_ADMIN_ERROR);
		} finally {
			try {
				if(resultSet!=null)
					resultSet.close();
				if(preparedStatement!=null)
					preparedStatement.close();
				if(connObj!=null)
					connObj.close();
				}
			catch (SQLException e2) {
				throw new GrizzleException(IGrizzleMessages.CLOSING_RESOURCE_ERROR);
				
			}
			
			/*
			 * if(connObj!=null) { connObj.close(); }
			 */

		}

		return empId;
	}
	
	public int deleteProductImages(int []pid) throws GrizzleException {

		 Connection connObj=null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int count = 0;
		//insert into product values(1,'bulb','bulb rises when sunset',1234.34,1.4,1002,103,"available");
//
		String query = "delete from product_gallery  where pr_id_fk in" ;
		try {
			connObj=ConnectionUtil.getConnection();
			if (connObj == null) {
				System.out.println("not Got connection");
			} else {
				System.out.println("Got Connected");
			}
			
			
			StringBuffer sb=new StringBuffer();
			
			for (int i = 0; i < pid.length; i++) {
				sb.append(pid[i]+",");
			}
			sb.deleteCharAt(sb.length()-1);
			
			System.out.println(sb);
			query+="("+sb.toString()+")";
			//preparedStatement.setString(1, sb.toString());
		System.out.println(query);
		preparedStatement = connObj.prepareStatement(query);

			 count = preparedStatement.executeUpdate();

			

			if (count >= 1) {
				System.out.println("Product gallery is deleted"+count);
			} else {

				throw new GrizzleException("Product gallery is not deleted some internal error");
			}

			/*
			 * if(resultSet!=null) resultSet.close();
			 */

		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			// classNotFoundException.printStackTrace();
			throw new GrizzleException(IGrizzleMessages.SOME_SQL_ERROR);
		} catch (Exception e) {
			e.printStackTrace();
			throw new GrizzleException(IGrizzleMessages.CONTACT_TO_ADMIN_ERROR);
		} finally {
			try {
				if(resultSet!=null)
					resultSet.close();
				if(preparedStatement!=null)
					preparedStatement.close();
				if(connObj!=null)
					connObj.close();
				}
			catch (SQLException e2) {
				throw new GrizzleException(IGrizzleMessages.CLOSING_RESOURCE_ERROR);
				
			}
			
			/*
			 * if(connObj!=null) { connObj.close(); }
			 */

		}

		return count;
	}
}
