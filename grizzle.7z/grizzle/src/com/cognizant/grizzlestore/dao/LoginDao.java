package com.cognizant.grizzlestore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cognizant.grizzlestore.exception.GrizzleException;
import com.cognizant.grizzlestore.model.LoginDetails;
import com.cognizant.grizzlestore.util.ConnectionUtil;
import com.cognizant.grizzlestore.util.IGrizzleMessages;



public class LoginDao {

	public LoginDao() {
		// TODO Auto-generated constructor stub
	}
	public LoginDetails checkLogin(LoginDetails loginDetails) throws GrizzleException
	{
		String user="";
		LoginDetails details=null;
		Connection connObj=null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{   
			connObj=ConnectionUtil.getConnection();
			if(connObj==null)
			{
			System.out.println("not Got connection");
			}
		else
			System.out.println("Got Connected");
			
	 preparedStatement = connObj.prepareStatement("Select * from login where username=? and password=?");
		preparedStatement.setString(1,loginDetails.getUsername());
		preparedStatement.setString(2,loginDetails.getPassword());
		resultSet = preparedStatement.executeQuery();
		if(resultSet.next())
		{
			String username=resultSet.getString("username");
			String password=resultSet.getString("password");
			String address=resultSet.getString("address");
			 details=new LoginDetails(username, password, "", 0, address);
			//System.out.println("Welcome-->"+uname);
			
		}
		else
			return details;
		if(resultSet!=null)
			resultSet.close();
		if(preparedStatement!=null)
			preparedStatement.close();
		if(connObj!=null)
			connObj.close();
		}
		catch(ClassNotFoundException classNotFoundException)
		{
			//classNotFoundException.printStackTrace();
			throw new GrizzleException(IGrizzleMessages.DRIVER_MISSING_ERROR);
		}
		catch(SQLException sqlException)
		{
			//classNotFoundException.printStackTrace();
			throw new GrizzleException(IGrizzleMessages.SOME_SQL_ERROR);
		}
		catch(Exception e)
		{
			throw new GrizzleException(IGrizzleMessages.CONTACT_TO_ADMIN_ERROR);
			}
		return details;
	}
	
	
	public int checkUsername(String username) throws GrizzleException
	{
		int flag=0;
		Connection connObj=null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{   
			connObj=ConnectionUtil.getConnection();
			if(connObj==null)
			{
			System.out.println("not Got connection");
			}
		else
			System.out.println("Got Connected");
			
	 preparedStatement = connObj.prepareStatement("Select username from login where username=? ");
		preparedStatement.setString(1,username);
		
		resultSet = preparedStatement.executeQuery();
		if(resultSet.next())
		{
			String uname=resultSet.getString("username");
			
			//System.out.println("Welcome-->"+uname);
			flag=1;
		}
		else
			return flag;
		if(resultSet!=null)
			resultSet.close();
		if(preparedStatement!=null)
			preparedStatement.close();
		if(connObj!=null)
			connObj.close();
		}
		catch(ClassNotFoundException classNotFoundException)
		{
			//classNotFoundException.printStackTrace();
			throw new GrizzleException(IGrizzleMessages.DRIVER_MISSING_ERROR);
		}
		catch(SQLException sqlException)
		{
			//classNotFoundException.printStackTrace();
			throw new GrizzleException(IGrizzleMessages.SOME_SQL_ERROR);
		}
		catch(Exception e)
		{
			throw new GrizzleException(IGrizzleMessages.CONTACT_TO_ADMIN_ERROR);
			}
		return flag;
	}
	
	public int updateStatus(String username) throws GrizzleException
	{
		int flag=0;
		Connection connObj=null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{   
			connObj=ConnectionUtil.getConnection();
			if(connObj==null)
			{
			System.out.println("not Got connection");
			}
		else
			System.out.println("Got Connected");
		//	if(zero==0) {
	 preparedStatement = connObj.prepareStatement("update login set attempt=attempt+1 where username=? ");
		preparedStatement.setString(1,username);
		
		int count = preparedStatement.executeUpdate();
		
		
		
		}catch(ClassNotFoundException classNotFoundException)
		{
			classNotFoundException.printStackTrace();
			throw new GrizzleException(IGrizzleMessages.DRIVER_MISSING_ERROR);
		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			//classNotFoundException.printStackTrace();
			throw new GrizzleException(IGrizzleMessages.SOME_SQL_ERROR);
		}
		catch(Exception e)
		{e.printStackTrace();
			throw new GrizzleException(IGrizzleMessages.CONTACT_TO_ADMIN_ERROR);
			}finally {
				try {
				if(resultSet!=null)
					resultSet.close();
				if(preparedStatement!=null)
					preparedStatement.close();
				if(connObj!=null)
					connObj.close();
				}
			catch (SQLException e2) {
				throw new GrizzleException(IGrizzleMessages.CLOSING_RESOURCE_ERROR);
				
			}
	}
				
			
		
		
		return flag;
	}
	
	public int getStatus(String username) throws GrizzleException
	{
		int status=0;
		Connection connObj=null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{   
			connObj=ConnectionUtil.getConnection();
			if(connObj==null)
			{
			System.out.println("not Got connection");
			}
		else
			System.out.println("Got Connected");
			
	 preparedStatement = connObj.prepareStatement("select attempt from login where username=? ");
		preparedStatement.setString(1,username);
		
	resultSet=preparedStatement.executeQuery();
	
	if(resultSet.next()) {
		
		status=resultSet.getInt("attempt");
	}
		
		
		}catch(ClassNotFoundException classNotFoundException)
		{
			//classNotFoundException.printStackTrace();
			throw new GrizzleException(IGrizzleMessages.DRIVER_MISSING_ERROR);
		}
		catch(SQLException sqlException)
		{
			//classNotFoundException.printStackTrace();
			throw new GrizzleException(IGrizzleMessages.SOME_SQL_ERROR);
		}
		catch(Exception e)
		{
			throw new GrizzleException(IGrizzleMessages.CONTACT_TO_ADMIN_ERROR);
			}finally {
				try {
				if(resultSet!=null)
					resultSet.close();
				if(preparedStatement!=null)
					preparedStatement.close();
				if(connObj!=null)
					connObj.close();
				}
			catch (SQLException e2) {
				throw new GrizzleException(IGrizzleMessages.CLOSING_RESOURCE_ERROR);
				
			}
	}
				
			
		
		
		return status;
	}
	//make attempt as zero
	public int afterLogoutUpdateStatus(String username) throws GrizzleException
	{
		int count=0;
		Connection connObj=null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{   
			connObj=ConnectionUtil.getConnection();
			if(connObj==null)
			{
			System.out.println("not Got connection");
			}
		else
			System.out.println("Got Connected");
		//	if(zero==0) {
	 preparedStatement = connObj.prepareStatement("update login set attempt=0 where username=? ");
		preparedStatement.setString(1,username);
		
		 count = preparedStatement.executeUpdate();
		
		
		
		}catch(ClassNotFoundException classNotFoundException)
		{
			classNotFoundException.printStackTrace();
			throw new GrizzleException(IGrizzleMessages.DRIVER_MISSING_ERROR);
		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			//classNotFoundException.printStackTrace();
			throw new GrizzleException(IGrizzleMessages.SOME_SQL_ERROR);
		}
		catch(Exception e)
		{e.printStackTrace();
			throw new GrizzleException(IGrizzleMessages.CONTACT_TO_ADMIN_ERROR);
			}finally {
				try {
				if(resultSet!=null)
					resultSet.close();
				if(preparedStatement!=null)
					preparedStatement.close();
				if(connObj!=null)
					connObj.close();
				}
			catch (SQLException e2) {
				throw new GrizzleException(IGrizzleMessages.CLOSING_RESOURCE_ERROR);
				
			}
	}
				
			
		
		
		return count;
	}
	
	

}
